package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.orbit.EventHandler;

/**
 * Wraps Meteor's built-in Freecam and lets you set how far the camera
 * may travel from your player (1000 - 5000 blocks).
 */
public class FarFreecam extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
        .name("range")
        .description("Max camera distance from your player, in blocks.")
        .defaultValue(1000)
        .range(1000, 5000)
        .sliderRange(1000, 5000)
        .build());

    private final Setting<Boolean> autoOff = sgGeneral.add(new BoolSetting.Builder()
        .name("disable-at-limit")
        .description("Turn freecam off when the camera passes the range.")
        .defaultValue(true)
        .build());

    public FarFreecam() {
        super(TruongbakhiAddon.CATEGORY, "far-freecam", "Freecam with a 1000-5000 block range.");
    }

    @Override
    public void onActivate() {
        Freecam fc = Modules.get().get(Freecam.class);
        if (!fc.isActive()) fc.toggle();
    }

    @Override
    public void onDeactivate() {
        Freecam fc = Modules.get().get(Freecam.class);
        if (fc.isActive()) fc.toggle();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.gameRenderer == null) return;

        Freecam fc = Modules.get().get(Freecam.class);
        if (!fc.isActive()) { // user turned Freecam off manually
            toggle();
            return;
        }

        double dx = fc.pos.x - mc.player.getX();
        double dy = fc.pos.y - mc.player.getY();
        double dz = fc.pos.z - mc.player.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > range.get() && autoOff.get()) {
            warning("Reached max range (" + range.get() + " blocks).");
            toggle();
        }
    }
}
