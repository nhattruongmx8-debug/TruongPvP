Build (cần internet + JDK 21):
  1. Cài Gradle 8.14+ (hoặc copy gradlew/gradle-wrapper từ meteor-addon-template vào thư mục này)
  2. gradle build
  3. File jar: build/libs/truongbakhi-1.0.0.jar  (bỏ vào .minecraft/mods cùng Meteor Client + Fabric Loader)
Nếu lỗi version: sửa gradle.properties theo https://fabricmc.net/develop và meteor-addon-template.
