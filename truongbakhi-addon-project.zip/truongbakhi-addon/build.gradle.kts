plugins {
    id("fabric-loom") version "1.14-SNAPSHOT"
}

base { archivesName = providers.gradleProperty("archives_base_name").get() }
group = providers.gradleProperty("maven_group").get()
version = providers.gradleProperty("mod_version").get()

repositories {
    mavenCentral()
    maven("https://maven.meteordev.org/releases") { name = "Meteor Dev Releases" }
    maven("https://maven.meteordev.org/snapshots") { name = "Meteor Dev Snapshots" }
}

dependencies {
    minecraft("com.mojang:minecraft:${providers.gradleProperty("minecraft_version").get()}")
    mappings("net.fabricmc:yarn:${providers.gradleProperty("yarn_mappings").get()}:v2")
    modImplementation("net.fabricmc:fabric-loader:${providers.gradleProperty("loader_version").get()}")
    modImplementation("meteordevelopment:meteor-client:${providers.gradleProperty("meteor_version").get()}")
}

tasks {
    processResources {
        inputs.property("version", project.version)
        filesMatching("fabric.mod.json") { expand("version" to project.version) }
    }
    withType<JavaCompile> {
        options.encoding = "UTF-8"
        options.release = 21
    }
    jar { from("LICENSE") { rename { "${it}_${project.base.archivesName.get()}" } } }
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}
