package com.truongbakhi.addon;

import com.truongbakhi.addon.modules.AnchorMacro;
import com.truongbakhi.addon.modules.CrystalLegit;
import com.truongbakhi.addon.modules.FarFreecam;
import com.truongbakhi.addon.modules.FlyModule;
import com.truongbakhi.addon.modules.ShopBuyer;
import com.truongbakhi.addon.modules.WindChargeMacro;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TruongbakhiAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("truongbakhi");
    public static final Category CATEGORY = new Category("truongbakhi");

    @Override
    public void onInitialize() {
        LOG.info("Initializing truongbakhi addon");
        Modules.get().add(new FarFreecam());
        Modules.get().add(new CrystalLegit());
        Modules.get().add(new AnchorMacro());
        Modules.get().add(new ShopBuyer());
        Modules.get().add(new FlyModule());
        Modules.get().add(new WindChargeMacro());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.truongbakhi.addon";
    }
}
