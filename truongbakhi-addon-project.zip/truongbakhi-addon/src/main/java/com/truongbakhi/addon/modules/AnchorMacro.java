package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Anchor macro: aim at a respawn anchor and hold right click.
 * It charges the anchor with glowstone, then switches slot and detonates it.
 * Optionally places an anchor first if you hold one and aim at a block.
 */
public class AnchorMacro extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> glowstoneSlot = sgGeneral.add(new IntSetting.Builder()
        .name("glowstone-slot")
        .description("Hotbar slot (1-9) holding glowstone.")
        .defaultValue(2)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Integer> explodeSlot = sgGeneral.add(new IntSetting.Builder()
        .name("explode-slot")
        .description("Hotbar slot (1-9) with any non-glowstone item (e.g. totem) used to detonate.")
        .defaultValue(3)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> place = sgGeneral.add(new BoolSetting.Builder()
        .name("place-anchor")
        .description("Place the anchor you are holding on the block you aim at.")
        .defaultValue(false)
        .build());

    private final Setting<Integer> charges = sgGeneral.add(new IntSetting.Builder()
        .name("charges")
        .description("Glowstone charges before detonating (1-4).")
        .defaultValue(1)
        .range(1, 4)
        .sliderRange(1, 4)
        .build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Ticks between actions.")
        .defaultValue(2)
        .range(0, 20)
        .sliderMax(10)
        .build());

    private final Setting<Boolean> requireKey = sgGeneral.add(new BoolSetting.Builder()
        .name("require-right-click")
        .description("Only act while right click is held.")
        .defaultValue(true)
        .build());

    private int cooldown;

    public AnchorMacro() {
        super(TruongbakhiAddon.CATEGORY, "anchor-macro", "Charge and explode respawn anchors.");
    }

    @Override
    public void onActivate() {
        cooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        if (requireKey.get() && !mc.options.useKey.isPressed()) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.world.getBlockState(hit.getBlockPos());

        // Place anchor
        if (state.getBlock() != Blocks.RESPAWN_ANCHOR) {
            if (place.get() && mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
                interact(hit);
            }
            return;
        }

        int current = state.get(RespawnAnchorBlock.CHARGES);

        if (current < charges.get()) {
            InvUtils.swap(glowstoneSlot.get() - 1, false);
            if (mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) interact(hit);
        } else if (current > 0) {
            InvUtils.swap(explodeSlot.get() - 1, false);
            if (!mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) interact(hit);
        }
    }

    private void interact(BlockHitResult hit) {
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        cooldown = delay.get();
    }
}
