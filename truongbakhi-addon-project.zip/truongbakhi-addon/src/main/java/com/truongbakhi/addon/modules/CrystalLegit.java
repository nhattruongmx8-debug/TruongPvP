package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Legit-style crystal helper: only acts on what your crosshair is already on,
 * only while you hold the mouse button, with randomized delays. No rotations.
 */
public class CrystalLegit extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> place = sgGeneral.add(new BoolSetting.Builder()
        .name("place")
        .description("Place a crystal on obsidian/bedrock you are aiming at (hold right click).")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> explode = sgGeneral.add(new BoolSetting.Builder()
        .name("break")
        .description("Hit the crystal you are aiming at (hold left click).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> minDelay = sgGeneral.add(new IntSetting.Builder()
        .name("min-delay")
        .description("Minimum ticks between actions.")
        .defaultValue(2)
        .range(0, 20)
        .sliderMax(10)
        .build());

    private final Setting<Integer> maxDelay = sgGeneral.add(new IntSetting.Builder()
        .name("max-delay")
        .description("Maximum ticks between actions.")
        .defaultValue(4)
        .range(0, 20)
        .sliderMax(10)
        .build());

    private final Setting<Boolean> requireKey = sgGeneral.add(new BoolSetting.Builder()
        .name("require-mouse-held")
        .description("Only act while the matching mouse button is held.")
        .defaultValue(true)
        .build());

    private int cooldown;

    public CrystalLegit() {
        super(TruongbakhiAddon.CATEGORY, "crystal-legit", "Human-like crystal placing and breaking.");
    }

    @Override
    public void onActivate() {
        cooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        HitResult hit = mc.crosshairTarget;
        if (hit == null) return;

        // Break crystal under crosshair
        if (explode.get() && hit instanceof EntityHitResult ehr
            && ehr.getEntity() instanceof EndCrystalEntity crystal
            && (!requireKey.get() || mc.options.attackKey.isPressed())) {
            mc.interactionManager.attackEntity(mc.player, crystal);
            mc.player.swingHand(Hand.MAIN_HAND);
            resetCooldown();
            return;
        }

        // Place crystal on obsidian / bedrock under crosshair
        if (place.get() && hit instanceof BlockHitResult bhr
            && hit.getType() == HitResult.Type.BLOCK
            && mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)
            && (!requireKey.get() || mc.options.useKey.isPressed())) {

            var block = mc.world.getBlockState(bhr.getBlockPos()).getBlock();
            if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) {
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, bhr);
                mc.player.swingHand(Hand.MAIN_HAND);
                resetCooldown();
            }
        }
    }

    private void resetCooldown() {
        int lo = Math.min(minDelay.get(), maxDelay.get());
        int hi = Math.max(minDelay.get(), maxDelay.get());
        cooldown = ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }
}
