package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

/** Simple velocity-based fly. Works in singleplayer / servers that allow flight. */
public class FlyModule extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Horizontal fly speed (blocks per tick).")
        .defaultValue(0.5)
        .range(0.05, 5.0)
        .sliderRange(0.05, 2.0)
        .build());

    private final Setting<Double> verticalSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Up/down speed with jump / sneak.")
        .defaultValue(0.4)
        .range(0.05, 3.0)
        .sliderRange(0.05, 2.0)
        .build());

    public FlyModule() {
        super(TruongbakhiAddon.CATEGORY, "fly", "Fly with WASD, jump to go up, sneak to go down.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null) return;

        double yaw = Math.toRadians(mc.player.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // forward
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // right

        double x = 0, z = 0, y = 0;
        if (mc.options.forwardKey.isPressed()) { x += fx; z += fz; }
        if (mc.options.backKey.isPressed())    { x -= fx; z -= fz; }
        if (mc.options.rightKey.isPressed())   { x += rx; z += rz; }
        if (mc.options.leftKey.isPressed())    { x -= rx; z -= rz; }

        double len = Math.sqrt(x * x + z * z);
        if (len > 0) { x = x / len * speed.get(); z = z / len * speed.get(); }

        if (mc.options.jumpKey.isPressed()) y += verticalSpeed.get();
        if (mc.options.sneakKey.isPressed()) y -= verticalSpeed.get();

        mc.player.setVelocity(x, y, z);
    }
}
