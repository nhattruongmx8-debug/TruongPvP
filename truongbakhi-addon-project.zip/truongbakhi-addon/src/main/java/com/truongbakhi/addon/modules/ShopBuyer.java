package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Auto shop buyer: runs a command (e.g. /shop), clicks the item slot,
 * optionally clicks a confirm slot, closes the menu, and repeats.
 */
public class ShopBuyer extends Module {
    private enum Step { SEND, WAIT_SCREEN, CLICK_ITEM, CLICK_CONFIRM, CLOSE }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<String> command = sgGeneral.add(new StringSetting.Builder()
        .name("command")
        .description("Command or message that opens the shop.")
        .defaultValue("/shop")
        .build());

    private final Setting<Integer> itemSlot = sgGeneral.add(new IntSetting.Builder()
        .name("item-slot")
        .description("Menu slot of the item to buy (0 = top-left).")
        .defaultValue(0)
        .range(0, 53)
        .sliderRange(0, 53)
        .build());

    private final Setting<Integer> confirmSlot = sgGeneral.add(new IntSetting.Builder()
        .name("confirm-slot")
        .description("Menu slot of the confirm button (-1 = none).")
        .defaultValue(-1)
        .range(-1, 53)
        .sliderRange(-1, 53)
        .build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Ticks between steps.")
        .defaultValue(5)
        .range(1, 40)
        .sliderMax(20)
        .build());

    private final Setting<Integer> maxBuys = sgGeneral.add(new IntSetting.Builder()
        .name("max-purchases")
        .description("Stop after this many purchases (0 = unlimited).")
        .defaultValue(0)
        .min(0)
        .sliderMax(500)
        .build());

    private Step step;
    private int timer, timeout, bought;

    public ShopBuyer() {
        super(TruongbakhiAddon.CATEGORY, "shop-buyer", "Automatically buys an item from a shop menu.");
    }

    @Override
    public void onActivate() {
        step = Step.SEND;
        timer = 0;
        bought = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.getNetworkHandler() == null || mc.interactionManager == null) return;

        if (timer > 0) {
            timer--;
            return;
        }

        switch (step) {
            case SEND -> {
                String cmd = command.get().trim();
                if (cmd.startsWith("/")) mc.getNetworkHandler().sendChatCommand(cmd.substring(1));
                else mc.getNetworkHandler().sendChatMessage(cmd);
                timeout = 40;
                step = Step.WAIT_SCREEN;
            }
            case WAIT_SCREEN -> {
                if (mc.currentScreen instanceof GenericContainerScreen) {
                    step = Step.CLICK_ITEM;
                    timer = delay.get();
                } else if (--timeout <= 0) {
                    step = Step.SEND;
                    timer = delay.get();
                }
            }
            case CLICK_ITEM -> {
                click(itemSlot.get());
                step = confirmSlot.get() >= 0 ? Step.CLICK_CONFIRM : Step.CLOSE;
                timer = delay.get();
            }
            case CLICK_CONFIRM -> {
                click(confirmSlot.get());
                step = Step.CLOSE;
                timer = delay.get();
            }
            case CLOSE -> {
                mc.player.closeHandledScreen();
                bought++;
                if (maxBuys.get() > 0 && bought >= maxBuys.get()) {
                    info("Finished: " + bought + " purchases.");
                    toggle();
                    return;
                }
                step = Step.SEND;
                timer = delay.get();
            }
        }
    }

    private void click(int slot) {
        if (mc.currentScreen instanceof GenericContainerScreen screen) {
            mc.interactionManager.clickSlot(screen.getScreenHandler().syncId, slot, 0, SlotActionType.PICKUP, mc.player);
        }
    }
}
