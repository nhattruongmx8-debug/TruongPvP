package com.truongbakhi.addon.modules;

import com.truongbakhi.addon.TruongbakhiAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Hand;

/**
 * Wind charge macro (mace combo). Bind a key to this module in Meteor and press it:
 * swaps to wind charge, looks down, throws it, jumps, then swaps to the mace.
 * The module turns itself off when the sequence is done.
 */
public class WindChargeMacro extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> windSlot = sgGeneral.add(new IntSetting.Builder()
        .name("wind-charge-slot")
        .description("Hotbar slot (1-9) holding wind charges.")
        .defaultValue(2)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Integer> maceSlot = sgGeneral.add(new IntSetting.Builder()
        .name("mace-slot")
        .description("Hotbar slot (1-9) holding the mace.")
        .defaultValue(1)
        .range(1, 9)
        .sliderRange(1, 9)
        .build());

    private final Setting<Boolean> lookDown = sgGeneral.add(new BoolSetting.Builder()
        .name("look-down")
        .description("Aim straight down before throwing, then restore your view.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> jump = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-jump")
        .description("Jump right after throwing (when on the ground).")
        .defaultValue(true)
        .build());

    private final Setting<Integer> swapDelay = sgGeneral.add(new IntSetting.Builder()
        .name("swap-delay")
        .description("Ticks between the throw and switching back to the mace.")
        .defaultValue(2)
        .range(1, 20)
        .sliderMax(10)
        .build());

    private int step, timer;
    private float savedPitch;

    public WindChargeMacro() {
        super(TruongbakhiAddon.CATEGORY, "wind-charge-macro", "Wind charge launch then swap to mace.");
    }

    @Override
    public void onActivate() {
        step = 0;
        timer = 0;
        if (mc.player != null) savedPitch = mc.player.getPitch();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.interactionManager == null) {
            toggle();
            return;
        }

        switch (step) {
            case 0 -> {
                InvUtils.swap(windSlot.get() - 1, false);
                if (lookDown.get()) mc.player.setPitch(90f);
                step = 1;
            }
            case 1 -> {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.swingHand(Hand.MAIN_HAND);
                if (jump.get() && mc.player.isOnGround()) mc.player.jump();
                timer = swapDelay.get();
                step = 2;
            }
            case 2 -> {
                if (--timer > 0) return;
                InvUtils.swap(maceSlot.get() - 1, false);
                if (lookDown.get()) mc.player.setPitch(savedPitch);
                toggle();
            }
        }
    }
}
