TruongPvP addon project (Minecraft 1.21.11)

Build requirements: JDK 21 and internet access for Gradle dependencies.

Build:
  ./gradlew build

Output:
  build/libs/truongbakhi-1.0.0.jar

Install the resulting JAR in the Minecraft mods folder with Fabric Loader and a compatible Meteor Client.

The addon registers its own 'truongbakhi' module category inside Meteor's existing GUI. It does not replace or recreate Meteor's GUI.
